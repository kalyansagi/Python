#Declaring variables

global f

f="play"
print("value of f is " + f)

f=123
print("value of f now is " +str(f))




