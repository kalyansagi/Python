import webbrowser

def func():
    webbrowser.open('quora.com')

func()    